package com.hollowburst;

public enum CutsceneType {
    BURST(0),   // C key: Reversal: Red
    SWORD(1),   // sword hit while airborne: Lapse: Blue
    MACE(2);    // mace hit while airborne: Hollow Purple

    public final int id;

    CutsceneType(int id) {
        this.id = id;
    }

    public static CutsceneType fromId(int id) {
        for (CutsceneType t : values()) {
            if (t.id == id) return t;
        }
        return BURST;
    }
}
