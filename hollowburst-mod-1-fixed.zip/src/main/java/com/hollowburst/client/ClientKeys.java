package com.hollowburst.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;

public final class ClientKeys {
    /** Default C. Rebindable in Options > Controls > Hollow Burst. */
    public static final KeyMapping ACTIVATE = new KeyMapping(
            "key.hollowburst.activate",
            InputConstants.KEY_C,
            "key.categories.hollowburst");

    private ClientKeys() {}
}
