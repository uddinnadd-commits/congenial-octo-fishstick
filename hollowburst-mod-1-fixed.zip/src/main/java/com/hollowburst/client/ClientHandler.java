package com.hollowburst.client;

import com.hollowburst.CutsceneType;
import com.hollowburst.network.CutscenePacket;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** Client-only entry point called by the cutscene packet. */
public final class ClientHandler {

    public static void startCutscene(CutscenePacket p) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        CutsceneType type = CutsceneType.fromId(p.typeId);
        CutsceneDef def = CutsceneDefs.get(type);

        Entity attacker = mc.level.getEntity(p.attackerId);
        Vec3 origin = attacker != null ? attacker.position() : mc.player.position();
        Vec3 focus = new Vec3(p.fx, p.fy, p.fz);
        Vec3 orb = new Vec3(p.ox, p.oy, p.oz);

        // where the action points, flattened onto the ground plane
        Vec3 dir;
        if (type == CutsceneType.BURST && attacker != null) {
            dir = attacker.getViewVector(1.0F);
        } else {
            dir = focus.subtract(origin);
        }
        Vec3 fwd = new Vec3(dir.x, 0.0, dir.z);
        fwd = fwd.lengthSqr() < 1.0E-4 ? new Vec3(0.0, 0.0, 1.0) : fwd.normalize();
        Vec3 side = new Vec3(-fwd.z, 0.0, fwd.x);

        CutsceneCtx ctx = new CutsceneCtx(type, p.attackerId, p.targetId, focus, orb, p.cinematic, fwd, side, origin);

        WorldFx.start(ctx, def.durationMs);
        PlayerAnims.start(p.attackerId, type);
        if (p.cinematic) {
            CutscenePlayer.start(def, ctx);
        }
    }

    private ClientHandler() {}
}
