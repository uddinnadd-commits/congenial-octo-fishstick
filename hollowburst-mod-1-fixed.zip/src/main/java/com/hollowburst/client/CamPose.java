package com.hollowburst.client;

import net.minecraft.world.phys.Vec3;

/** One camera position + look-at point, with an optional FOV multiplier and roll (degrees). */
public record CamPose(Vec3 pos, Vec3 look, double fov, double roll) {
    public static CamPose of(Vec3 pos, Vec3 look) {
        return new CamPose(pos, look, 1.0, 0.0);
    }

    public static CamPose of(Vec3 pos, Vec3 look, double fov) {
        return new CamPose(pos, look, fov, 0.0);
    }

    public static CamPose of(Vec3 pos, Vec3 look, double fov, double roll) {
        return new CamPose(pos, look, fov, roll);
    }
}
