package com.hollowburst.client;

import com.hollowburst.HollowBurstMod;
import com.hollowburst.network.ActivatePacket;
import com.hollowburst.network.Net;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.Set;

@Mod.EventBusSubscriber(modid = HollowBurstMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientForgeEvents {

    /** HUD pieces hidden while a cutscene plays. */
    private static boolean playerRenderBroken;

    // ------------------------------------------------------------------ ticks and input

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        CutscenePlayer.tick(mc);

        while (ClientKeys.ACTIVATE.consumeClick()) {
            if (mc.player == null || mc.screen != null || CutscenePlayer.inputLocked()) continue;
            try {
                Net.CHANNEL.send(new ActivatePacket(), PacketDistributor.SERVER.noArg());
            } catch (Exception ex) {
                HollowBurstMod.LOGGER.warn("Could not send Hollow Burst activation (server without the mod?)", ex);
            }
        }
    }

    /** Runs every frame before the camera is set up: this is where the free camera is placed. */
    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent.Pre event) {
        Minecraft mc = Minecraft.getInstance();
        CutscenePlayer.onRenderTick(mc, event.getTimer().getGameTimeDeltaPartialTick(false));
    }

    /** No walking, jumping or sneaking while the cutscene holds the player. */
    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent event) {
        if (!CutscenePlayer.inputLocked()) return;
        Input in = event.getInput();
        in.up = false;
        in.down = false;
        in.left = false;
        in.right = false;
        in.forwardImpulse = 0.0F;
        in.leftImpulse = 0.0F;
        in.jumping = false;
        in.shiftKeyDown = false;
    }

    /** No swinging or using items while the cutscene holds the player. */
    @SubscribeEvent
    public static void onInteract(InputEvent.InteractionKeyMappingTriggered event) {
        if (CutscenePlayer.inputLocked()) {
            event.setCanceled(true);
            event.setSwingHand(false);
        }
    }

    // ------------------------------------------------------------------ camera

    @SubscribeEvent
    public static void onFov(ViewportEvent.ComputeFov event) {
        CutsceneDef def = CutscenePlayer.def();
        if (def == null || !event.usedConfiguredFov()) return;
        long t = CutscenePlayer.elapsedMs();
        double mult = def.fov.applyAsDouble(t);
        if (CutscenePlayer.rigActive()) mult *= CameraRig.fovMult();
        event.setFOV(event.getFOV() * mult);
    }

    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        CutsceneDef def = CutscenePlayer.def();
        if (def == null) return;
        long ms = CutscenePlayer.elapsedMs();
        double t = ms * 0.001;
        double amp = def.shake.applyAsDouble(ms);

        float yaw = event.getYaw() + (float) (amp * (Math.sin(t * 53.0) + 0.5 * Math.sin(t * 97.0)));
        float pitch = event.getPitch() + (float) (amp * (Math.sin(t * 61.0 + 1.3) + 0.5 * Math.sin(t * 89.0)));
        float roll = event.getRoll()
                + (float) def.roll.applyAsDouble(ms)
                + (CutscenePlayer.rigActive() ? (float) CameraRig.roll() : 0.0F)
                + (float) (amp * 0.6 * Math.sin(t * 71.0 + 2.1));

        event.setYaw(yaw);
        event.setPitch(pitch);
        event.setRoll(roll);
    }

    /** The first-person hand has no place in a cinematic shot. */
    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        if (CutscenePlayer.rigActive()) {
            event.setCanceled(true);
        }
    }

    // ------------------------------------------------------------------ world rendering

    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() == RenderLevelStageEvent.Stage.AFTER_ENTITIES) {
            drawLocalPlayerForRig(event);
        } else if (event.getStage() == RenderLevelStageEvent.Stage.AFTER_PARTICLES) {
            WorldFx.render(event);
        }
    }

    /**
     * With the camera detached from the player the game stops drawing the local player,
     * so during a cinematic we draw them ourselves.
     */
    private static void drawLocalPlayerForRig(RenderLevelStageEvent event) {
        if (playerRenderBroken || !CutscenePlayer.rigActive()) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;
        try {
            Camera camera = event.getCamera();
            Vec3 c = camera.getPosition();
            float pt = event.getPartialTick();
            double x = Mth.lerp(pt, p.xo, p.getX());
            double y = Mth.lerp(pt, p.yo, p.getY());
            double z = Mth.lerp(pt, p.zo, p.getZ());

            PoseStack ps = new PoseStack();
            ps.mulPose(event.getPoseStack());
            MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
            EntityRenderDispatcher d = mc.getEntityRenderDispatcher();
            d.render(p, x - c.x, y - c.y, z - c.z, Mth.lerp(pt, p.yRotO, p.getYRot()), pt, ps, buffers,
                    d.getPackedLightCoords(p, pt));
            buffers.endBatch();
        } catch (Throwable ex) {
            playerRenderBroken = true;
            HollowBurstMod.LOGGER.warn("Hollow Burst: could not draw the player in cinematic mode", ex);
        }
    }

    @SubscribeEvent
    public static void onRenderLivingPre(RenderLivingEvent.Pre<?, ?> event) {
        PlayerAnims.pre(event);
    }

    @SubscribeEvent
    public static void onRenderLivingPost(RenderLivingEvent.Post<?, ?> event) {
        PlayerAnims.post(event);
    }

    private ClientForgeEvents() {}
}
