package com.hollowburst.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/** Glowing world-space shapes (spheres, rings, beams, slash arcs) drawn with additive blending. */
final class Mesh {

    private static void v(VertexConsumer vc, Matrix4f m, Vec3 cam, double x, double y, double z, int rgb, float a) {
        int alpha = (int) (Math.max(0.0F, Math.min(1.0F, a)) * 255.0F);
        vc.addVertex(m, (float) (x - cam.x), (float) (y - cam.y), (float) (z - cam.z))
                .setColor((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255, alpha);
    }

    static int whiten(int rgb, double amount) {
        int r = (rgb >> 16) & 255;
        int g = (rgb >> 8) & 255;
        int b = rgb & 255;
        r += (int) ((255 - r) * amount);
        g += (int) ((255 - g) * amount);
        b += (int) ((255 - b) * amount);
        return (r << 16) | (g << 8) | b;
    }

    /** A UV sphere made of quads. */
    static void sphere(VertexConsumer vc, Matrix4f m, Vec3 cam, Vec3 c, double r, int rgb, float alpha) {
        if (r <= 0.001 || alpha <= 0.002F) return;
        final int lat = 10;
        final int lon = 16;
        for (int i = 0; i < lat; i++) {
            double t0 = Math.PI * i / lat;
            double t1 = Math.PI * (i + 1) / lat;
            for (int j = 0; j < lon; j++) {
                double p0 = Math.PI * 2.0 * j / lon;
                double p1 = Math.PI * 2.0 * (j + 1) / lon;
                v(vc, m, cam, c.x + r * Math.sin(t0) * Math.cos(p0), c.y + r * Math.cos(t0), c.z + r * Math.sin(t0) * Math.sin(p0), rgb, alpha);
                v(vc, m, cam, c.x + r * Math.sin(t1) * Math.cos(p0), c.y + r * Math.cos(t1), c.z + r * Math.sin(t1) * Math.sin(p0), rgb, alpha);
                v(vc, m, cam, c.x + r * Math.sin(t1) * Math.cos(p1), c.y + r * Math.cos(t1), c.z + r * Math.sin(t1) * Math.sin(p1), rgb, alpha);
                v(vc, m, cam, c.x + r * Math.sin(t0) * Math.cos(p1), c.y + r * Math.cos(t0), c.z + r * Math.sin(t0) * Math.sin(p1), rgb, alpha);
            }
        }
    }

    /** A bright core wrapped in two softer shells: reads as a glowing energy ball. */
    static void glowSphere(VertexConsumer vc, Matrix4f m, Vec3 cam, Vec3 c, double r, int rgb, float alpha) {
        sphere(vc, m, cam, c, r, rgb, alpha * 0.30F);
        sphere(vc, m, cam, c, r * 0.78, rgb, alpha * 0.50F);
        sphere(vc, m, cam, c, r * 0.50, whiten(rgb, 0.65), alpha * 0.90F);
    }

    /** A flat ring in the horizontal plane at height c.y. */
    static void ring(VertexConsumer vc, Matrix4f m, Vec3 cam, Vec3 c, double r0, double r1, int rgb, float alpha) {
        if (alpha <= 0.002F || r1 <= r0) return;
        final int seg = 48;
        for (int i = 0; i < seg; i++) {
            double a0 = Math.PI * 2.0 * i / seg;
            double a1 = Math.PI * 2.0 * (i + 1) / seg;
            v(vc, m, cam, c.x + Math.cos(a0) * r0, c.y, c.z + Math.sin(a0) * r0, rgb, alpha);
            v(vc, m, cam, c.x + Math.cos(a0) * r1, c.y, c.z + Math.sin(a0) * r1, rgb, alpha * 0.2F);
            v(vc, m, cam, c.x + Math.cos(a1) * r1, c.y, c.z + Math.sin(a1) * r1, rgb, alpha * 0.2F);
            v(vc, m, cam, c.x + Math.cos(a1) * r0, c.y, c.z + Math.sin(a1) * r0, rgb, alpha);
        }
    }

    /** A vertical open cylinder that fades towards the top. */
    static void beam(VertexConsumer vc, Matrix4f m, Vec3 cam, Vec3 base, double radius, double height, int rgb, float alpha) {
        if (alpha <= 0.002F || radius <= 0.01) return;
        final int seg = 20;
        for (int i = 0; i < seg; i++) {
            double a0 = Math.PI * 2.0 * i / seg;
            double a1 = Math.PI * 2.0 * (i + 1) / seg;
            double x0 = base.x + Math.cos(a0) * radius;
            double z0 = base.z + Math.sin(a0) * radius;
            double x1 = base.x + Math.cos(a1) * radius;
            double z1 = base.z + Math.sin(a1) * radius;
            v(vc, m, cam, x0, base.y, z0, rgb, alpha);
            v(vc, m, cam, x0, base.y + height, z0, rgb, alpha * 0.15F);
            v(vc, m, cam, x1, base.y + height, z1, rgb, alpha * 0.15F);
            v(vc, m, cam, x1, base.y, z1, rgb, alpha);
        }
    }

    /**
     * A crescent: part of a circle of radius R around "center", in the plane spanned by u and v,
     * from angle a0 to a1 (degrees, measured from u towards v). It fades from the head (a1) to the tail (a0).
     */
    static void arc(VertexConsumer vc, Matrix4f m, Vec3 cam, Vec3 center, Vec3 u, Vec3 vv,
                    double radius, double width, double a0, double a1, int rgb, float alpha) {
        if (alpha <= 0.002F || a1 <= a0) return;
        final int seg = 24;
        for (int i = 0; i < seg; i++) {
            double s0 = i / (double) seg;
            double s1 = (i + 1) / (double) seg;
            double ang0 = Math.toRadians(a0 + (a1 - a0) * s0);
            double ang1 = Math.toRadians(a0 + (a1 - a0) * s1);
            double w0 = width * (0.15 + 0.85 * s0);
            double w1 = width * (0.15 + 0.85 * s1);
            float al0 = alpha * (float) s0;
            float al1 = alpha * (float) s1;
            Vec3 d0 = u.scale(Math.cos(ang0)).add(vv.scale(Math.sin(ang0)));
            Vec3 d1 = u.scale(Math.cos(ang1)).add(vv.scale(Math.sin(ang1)));
            Vec3 in0 = center.add(d0.scale(radius - w0 * 0.5));
            Vec3 out0 = center.add(d0.scale(radius + w0 * 0.5));
            Vec3 in1 = center.add(d1.scale(radius - w1 * 0.5));
            Vec3 out1 = center.add(d1.scale(radius + w1 * 0.5));
            v(vc, m, cam, in0.x, in0.y, in0.z, rgb, al0);
            v(vc, m, cam, out0.x, out0.y, out0.z, rgb, al0);
            v(vc, m, cam, out1.x, out1.y, out1.z, rgb, al1);
            v(vc, m, cam, in1.x, in1.y, in1.z, rgb, al1);
        }
    }

    private Mesh() {}
}
