package com.hollowburst.client;

import com.hollowburst.HollowBurstMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import com.mojang.blaze3d.vertex.VertexConsumer;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * The big glowing things you see in the world: the charging core and blast sphere of Red,
 * the blue vortex and crossing slashes of Blue, and the orbiting orbs, purple sphere,
 * shockwave rings and sky beam of Hollow Purple. Drawn for everybody who can see the caster.
 */
final class WorldFx {
    private static final int RED = 0xFF2A2A;
    private static final int ORANGE = 0xFFA040;
    private static final int BLUE = 0x2F7BFF;
    private static final int ICE = 0xBFE0FF;
    private static final int PURPLE = 0xA83CFF;
    private static final int LILAC = 0xD9A8FF;
    private static final int WHITE = 0xFFFFFF;

    private record Active(CutsceneCtx ctx, long startMs, long lifeMs) {}

    private static final List<Active> ACTIVE = new ArrayList<>();
    private static boolean broken;

    static void start(CutsceneCtx ctx, long durationMs) {
        ACTIVE.add(new Active(ctx, now(), durationMs + 500));
    }

    private static long now() {
        return System.nanoTime() / 1_000_000L;
    }

    static void render(RenderLevelStageEvent e) {
        if (ACTIVE.isEmpty() || broken) return;
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null) {
                ACTIVE.clear();
                return;
            }
            long now = now();
            Vec3 cam = e.getCamera().getPosition();
            Matrix4f m = e.getPoseStack();
            float partial = e.getPartialTick();

            MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();
            VertexConsumer vc = bs.getBuffer(RenderType.lightning());

            Iterator<Active> it = ACTIVE.iterator();
            while (it.hasNext()) {
                Active a = it.next();
                long ms = now - a.startMs();
                if (ms > a.lifeMs()) {
                    it.remove();
                    continue;
                }
                switch (a.ctx().type()) {
                    case BURST -> drawBurst(vc, m, cam, a.ctx(), ms, mc, partial);
                    case SWORD -> drawSword(vc, m, cam, a.ctx(), ms);
                    case MACE -> drawMace(vc, m, cam, a.ctx(), ms);
                }
            }
            bs.endBatch(RenderType.lightning());
        } catch (Throwable ex) {
            broken = true;
            HollowBurstMod.LOGGER.warn("Hollow Burst: world effects disabled after a render error", ex);
        }
    }

    private static double easeOut(double x) {
        x = Curves.clamp01(x);
        return 1.0 - (1.0 - x) * (1.0 - x) * (1.0 - x);
    }

    private static float fade(double x, double power) {
        return (float) Math.pow(1.0 - Curves.clamp01(x), power);
    }

    // ------------------------------------------------------------------ Red

    private static void drawBurst(VertexConsumer vc, Matrix4f m, Vec3 cam, CutsceneCtx ctx, long ms, Minecraft mc, float partial) {
        Vec3 c = ctx.focus();
        if (ms < 1200) {
            double k = Curves.smooth(ms / 1200.0);
            double r = 0.12 + 0.55 * k + 0.04 * Math.sin(ms * 0.05);
            Mesh.glowSphere(vc, m, cam, c, r, RED, 0.95F);
            // a faint shell collapsing into the core
            Mesh.sphere(vc, m, cam, c, 3.5 * (1.0 - k) + 0.6, RED, 0.10F);
            return;
        }

        double x = (ms - 1200) / 750.0;
        if (x < 1.0) {
            double e = easeOut(x);
            double r = 0.5 + 11.0 * e;
            Mesh.sphere(vc, m, cam, c, r, RED, 0.62F * fade(x, 1.4));
            Mesh.sphere(vc, m, cam, c, r * 0.80, ORANGE, 0.50F * fade(x, 2.0));
            Mesh.sphere(vc, m, cam, c, r * 0.35, WHITE, 0.90F * fade(x, 3.0));

            Vec3 ground = new Vec3(ctx.origin().x, ctx.origin().y + 0.06, ctx.origin().z);
            double r0 = 1.0 + 15.0 * e;
            Mesh.ring(vc, m, cam, ground, r0, r0 + 1.6 - 1.0 * x, ORANGE, 0.9F * fade(x, 1.2));
            double x2 = (ms - 1330) / 750.0;
            if (x2 > 0 && x2 < 1.0) {
                double r2 = 1.0 + 12.0 * easeOut(x2);
                Mesh.ring(vc, m, cam, ground, r2, r2 + 1.2, RED, 0.8F * fade(x2, 1.2));
            }
        }

        // a lingering red aura around the caster while they fly
        Entity att = mc.level.getEntity(ctx.attackerId());
        if (att != null && ms < 2900) {
            Vec3 p = att.getPosition(partial).add(0, 1.0, 0);
            double y = (ms - 1200) / 1700.0;
            Mesh.glowSphere(vc, m, cam, p, 0.9 * (1.0 - y) + 0.15, RED, 0.35F);
        }
    }

    // ------------------------------------------------------------------ Blue

    private static void drawSword(VertexConsumer vc, Matrix4f m, Vec3 cam, CutsceneCtx ctx, long ms) {
        Vec3 f = ctx.focus();

        if (ms < 2000) {
            double k = Curves.smooth(Math.min(ms, 1250) / 1250.0);
            double r = 0.3 + 1.1 * k + 0.06 * Math.sin(ms * 0.04);
            Mesh.glowSphere(vc, m, cam, f, r, BLUE, 0.95F);
            if (ms < 1250) {
                Mesh.sphere(vc, m, cam, f, 9.0 * (1.0 - k) + 1.4, BLUE, 0.10F);
            }
        } else {
            double x = (ms - 2000) / 800.0;
            if (x < 1.0) {
                double e = easeOut(Math.min(1.0, x * 1.4));
                double r = 1.4 + 6.0 * e;
                Mesh.sphere(vc, m, cam, f, r, BLUE, 0.50F * fade(x, 1.3));
                Mesh.sphere(vc, m, cam, f, r * 0.4, WHITE, 0.90F * fade(x, 2.0));
            }
        }

        // two crossing slashes
        if (ms >= 2000 && ms < 2700) {
            double sweep = Curves.clamp01((ms - 2000) / 130.0);
            double fadeOut = ms < 2130 ? 1.0 : 1.0 - (ms - 2130) / 570.0;
            float alpha = (float) Math.max(0.0, fadeOut);
            double head = 35.0 + 110.0 * sweep;
            double tail = Math.max(35.0, head - 75.0);
            for (int s = -1; s <= 1; s += 2) {
                double ang = Math.toRadians(35.0 * s);
                Vec3 u = ctx.side().scale(Math.cos(ang)).add(ShotEnv.UP.scale(Math.sin(ang)));
                Vec3 v = ctx.side().scale(-Math.sin(ang)).add(ShotEnv.UP.scale(Math.cos(ang)));
                double radius = 5.0;
                Vec3 center = f.subtract(v.scale(radius));
                Mesh.arc(vc, m, cam, center, u, v, radius, 0.75, tail, head, BLUE, alpha);
                Mesh.arc(vc, m, cam, center, u, v, radius, 0.28, tail, head, WHITE, alpha);
            }
        }
    }

    // ------------------------------------------------------------------ Purple

    private static void drawMace(VertexConsumer vc, Matrix4f m, Vec3 cam, CutsceneCtx ctx, long ms) {
        Vec3 c = ctx.orb();
        Vec3 f = ctx.focus();
        Vec3 axis = f.subtract(c);
        double len = axis.length();
        Vec3 axisN = len < 1.0E-3 ? ctx.fwd() : axis.scale(1.0 / len);
        Vec3 ref = Math.abs(axisN.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        Vec3 u = axisN.cross(ref).normalize();
        Vec3 v = axisN.cross(u).normalize();

        if (ms < 3000) {
            double a = (ms / 50.0) * 0.42;
            double r = 1.5 * (1.0 - ms / 3000.0) + 0.12;
            Vec3 off = u.scale(Math.cos(a) * r).add(v.scale(Math.sin(a) * r));
            Mesh.glowSphere(vc, m, cam, c.add(off), 0.30, RED, 1.0F);
            Mesh.glowSphere(vc, m, cam, c.subtract(off), 0.30, BLUE, 1.0F);
            Mesh.glowSphere(vc, m, cam, c, 0.12 + 0.3 * (ms / 3000.0), LILAC, 0.45F);
        } else if (ms < 3900) {
            double fly = Curves.smooth((ms - 3000) / 900.0);
            Vec3 pos = ShotEnv.mix(c, f, fly);
            double r = 0.7 + 0.9 * fly;
            Mesh.glowSphere(vc, m, cam, pos, r, PURPLE, 1.0F);
            Mesh.sphere(vc, m, cam, pos, r * 0.3, WHITE, 0.9F);
            double xm = (ms - 3000) / 250.0;
            if (xm < 1.0) {
                Mesh.sphere(vc, m, cam, c, 0.8 + 3.0 * xm, PURPLE, 0.6F * fade(xm, 1.5));
            }
        } else {
            double x = (ms - 3900) / 1400.0;
            if (x < 1.0) {
                double e = easeOut(x);
                double r = 1.6 + 17.0 * e;
                Mesh.sphere(vc, m, cam, f, r, PURPLE, 0.60F * fade(x, 1.3));
                Mesh.sphere(vc, m, cam, f, r * 0.70, LILAC, 0.50F * fade(x, 2.0));
                Mesh.sphere(vc, m, cam, f, r * 0.30, WHITE, 0.90F * fade(x, 3.0));

                Vec3 ground = new Vec3(f.x, f.y - 0.9, f.z);
                double r0 = 1.0 + 22.0 * e;
                Mesh.ring(vc, m, cam, ground, r0, r0 + 2.0 - 1.2 * x, LILAC, 0.9F * fade(x, 1.2));
                double x2 = (ms - 4150) / 1200.0;
                if (x2 > 0 && x2 < 1.0) {
                    double r2 = 1.0 + 18.0 * easeOut(x2);
                    Mesh.ring(vc, m, cam, ground, r2, r2 + 1.6, PURPLE, 0.8F * fade(x2, 1.2));
                }

                // the beam into the sky
                double br = 2.4 * (1.0 - x * 0.8) + 0.3;
                Mesh.beam(vc, m, cam, ground, br, 110.0, PURPLE, 0.8F * fade(x, 1.0));
                Mesh.beam(vc, m, cam, ground, br * 0.4, 110.0, WHITE, 0.95F * fade(x, 1.2));
            }
        }
    }

    private WorldFx() {}
}
