package com.hollowburst.client;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;

import java.util.List;

/** Runtime state of the cutscene currently playing (client only). */
public final class CutscenePlayer {
    private static final long FADE_IN_MS = 200;
    private static final long FADE_OUT_MS = 260;
    private static final long POST_FADE_MS = 320;

    private static CutsceneDef current;
    private static CutsceneCtx ctx;
    private static long startNanos;
    private static CameraType previousCamera;
    private static int appliedCut = -1;
    private static boolean rig;
    private static float lockYaw;
    private static float lockPitch;
    private static long postFadeStartMs = -1;

    public static void start(CutsceneDef def, CutsceneCtx context) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        boolean fresh = current == null;
        if (fresh) {
            previousCamera = mc.options.getCameraType();
            lockYaw = mc.player.getYRot();
            lockPitch = mc.player.getXRot();
            rig = CameraRig.start(mc);
        }
        current = def;
        ctx = context;
        startNanos = System.nanoTime();
        appliedCut = -1;
        postFadeStartMs = -1;
        if (!rig) applyCuts(mc, 0L);
    }

    public static CutsceneDef def() {
        return current;
    }

    public static CutsceneCtx ctx() {
        return ctx;
    }

    public static boolean active() {
        return current != null;
    }

    public static boolean rigActive() {
        return current != null && rig && CameraRig.isActive();
    }

    public static long elapsedMs() {
        return (System.nanoTime() - startNanos) / 1_000_000L;
    }

    /** True while the player should not be able to move, swing or turn. */
    public static boolean inputLocked() {
        return current != null && elapsedMs() < current.freezeMs;
    }

    /** 0..1 black overlay: fade-in at the start, fade-out at the end, fade-in again after the cut back. */
    public static double fadeAlpha() {
        if (current != null) {
            long t = elapsedMs();
            double in = 1.0 - Curves.clamp01(t / (double) FADE_IN_MS);
            double out = 1.0 - Curves.clamp01((current.durationMs - t) / (double) FADE_OUT_MS);
            return Math.max(in, out);
        }
        if (postFadeStartMs >= 0) {
            double x = (System.nanoTime() / 1_000_000L - postFadeStartMs) / (double) POST_FADE_MS;
            if (x >= 1.0) {
                postFadeStartMs = -1;
                return 0.0;
            }
            return 1.0 - Curves.clamp01(x);
        }
        return 0.0;
    }

    public static void tick(Minecraft mc) {
        if (current == null) return;
        CameraRig.tick();
        if (mc.player == null || mc.level == null || mc.player.isDeadOrDying()) {
            stop(mc);
            return;
        }
        long t = elapsedMs();
        if (t >= current.durationMs) {
            stop(mc);
            return;
        }
        if (!rig) applyCuts(mc, t);
    }

    /** Called once per rendered frame, before the camera is set up. */
    public static void onRenderTick(Minecraft mc, float partial) {
        if (current == null || mc.player == null) return;
        long t = elapsedMs();
        if (t >= current.durationMs) return;

        if (inputLocked()) {
            mc.player.setYRot(lockYaw);
            mc.player.setXRot(lockPitch);
            mc.player.yRotO = lockYaw;
            mc.player.xRotO = lockPitch;
        }
        if (rig && ctx != null) {
            CameraRig.update(mc, current, ctx, t, partial);
        }
    }

    private static void applyCuts(Minecraft mc, long t) {
        List<CutsceneDef.Cut> cuts = current.cuts;
        int idx = -1;
        for (int i = cuts.size() - 1; i >= 0; i--) {
            if (cuts.get(i).at() <= t) {
                idx = i;
                break;
            }
        }
        if (idx >= 0 && idx != appliedCut) {
            appliedCut = idx;
            mc.options.setCameraType(cuts.get(idx).camera());
        }
    }

    public static void stop(Minecraft mc) {
        if (rig) CameraRig.stop(mc);
        if (previousCamera != null) {
            mc.options.setCameraType(previousCamera);
        }
        current = null;
        ctx = null;
        previousCamera = null;
        appliedCut = -1;
        rig = false;
        postFadeStartMs = System.nanoTime() / 1_000_000L;
    }

    private CutscenePlayer() {}
}
