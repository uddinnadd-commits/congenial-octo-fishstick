package com.hollowburst.network;

import com.hollowburst.CutsceneType;
import com.hollowburst.client.ClientHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.network.CustomPayloadEvent;

/**
 * Server -> client: start a cutscene.
 * cinematic = true for the player who owns the cutscene (camera, letterbox, subtitles...),
 * false for onlookers, who only see the world effects and the body animation.
 */
public class CutscenePacket {
    public final int typeId;
    public final int attackerId;
    public final int targetId;
    public final double fx, fy, fz;   // focus point (target centre, or your chest for the C burst)
    public final double ox, oy, oz;   // orb centre (Hollow Purple)
    public final boolean cinematic;

    public CutscenePacket(CutsceneType type, int attackerId, int targetId, Vec3 focus, Vec3 orb, boolean cinematic) {
        this(type.id, attackerId, targetId, focus.x, focus.y, focus.z, orb.x, orb.y, orb.z, cinematic);
    }

    private CutscenePacket(int typeId, int attackerId, int targetId,
                           double fx, double fy, double fz, double ox, double oy, double oz, boolean cinematic) {
        this.typeId = typeId;
        this.attackerId = attackerId;
        this.targetId = targetId;
        this.fx = fx;
        this.fy = fy;
        this.fz = fz;
        this.ox = ox;
        this.oy = oy;
        this.oz = oz;
        this.cinematic = cinematic;
    }

    public static void encode(CutscenePacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.typeId);
        buf.writeInt(m.attackerId);
        buf.writeInt(m.targetId);
        buf.writeDouble(m.fx);
        buf.writeDouble(m.fy);
        buf.writeDouble(m.fz);
        buf.writeDouble(m.ox);
        buf.writeDouble(m.oy);
        buf.writeDouble(m.oz);
        buf.writeBoolean(m.cinematic);
    }

    public static CutscenePacket decode(FriendlyByteBuf buf) {
        return new CutscenePacket(buf.readVarInt(), buf.readInt(), buf.readInt(),
                buf.readDouble(), buf.readDouble(), buf.readDouble(),
                buf.readDouble(), buf.readDouble(), buf.readDouble(), buf.readBoolean());
    }

    public static void handle(CutscenePacket msg, CustomPayloadEvent.Context ctx) {
        // Only ever runs on the client (PLAY_TO_CLIENT). ClientHandler is a client-only class.
        ClientHandler.startCutscene(msg);
    }
}
